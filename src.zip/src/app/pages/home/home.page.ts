import { Component, inject, OnInit, OnDestroy } from '@angular/core';

import { ProductService } from '../../services/product/product.service';
import { Product } from '../../models/product.model';
import { CartService } from '../../services/cart/cart.service';

import { SHARED_IONIC_MODULES } from 'src/app/shared/shared.ionic';
import { ProductCardComponent } from 'src/app/components/product-card/product-card.component';
import { HeaderComponent } from 'src/app/components/header/header.component';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  standalone: true,
  imports: [...SHARED_IONIC_MODULES, ProductCardComponent, HeaderComponent],
})
export class HomePage implements OnInit, OnDestroy {
  products: Product[] = [];

  searchTerm = '';

  selectedCategoryId = 0;

  selectedFilter = 'Trending';

  currentBanner = 0;

  bannerInterval: any;

  filters = [
    'Trending',
    'Popular',
    'Latest',
    'Under ₹1000',
    '₹1000 - ₹5000',
    'Above ₹5000',
  ];

  banners = [
    {
      image: 'assets/images/banner.png',
      title: 'Mega Sale',
      subtitle: 'Up to 50% OFF',
    },
    {
      image: 'assets/images/banner.png',
      title: 'Trending Fashion',
      subtitle: 'New Collection',
    },
    {
      image: 'assets/images/banner.png',
      title: 'Electronics Week',
      subtitle: 'Best Deals Available',
    },
  ];

  categories: any[] = [];

  private productService = inject(ProductService);
  private cartService = inject(CartService);

  async ngOnInit() {
    this.products = await this.productService.getProducts();
    const apiCategories = await this.productService.getCategories();

    this.categories = [
      {
        id: 0,
        name: 'All',
        icon: 'apps',
      },
      ...apiCategories.map((item: any) => ({
        id: Number(item.id),
        name: item.name,
        image_url: item.image_url,
      })),
    ];

    this.startBannerAutoSlide();
  }

  startBannerAutoSlide(): void {
    if (this.bannerInterval) {
      clearInterval(this.bannerInterval);
    }

    this.bannerInterval = setInterval(() => {
      this.currentBanner = (this.currentBanner + 1) % this.banners.length;
    }, 3000);
  }

  setBanner(index: number): void {
    this.currentBanner = index;
  }

  selectCategory(category: any): void {
    this.selectedCategoryId = Number(category.id);
  }

  selectFilter(filter: string): void {
    this.selectedFilter = filter;
  }

  onSearchChange(): void {}

  clearSearch(): void {
    this.searchTerm = '';
  }

  get featuredProducts(): Product[] {
    return this.products.slice(0, 4);
  }

  get filteredProducts(): Product[] {
    let filtered = [...this.products];

    // CATEGORY FILTER
    if (this.selectedCategoryId > 0) {
      filtered = filtered.filter(
        (product: any) =>
          Number(product.category_id) === this.selectedCategoryId,
      );
    }

    // SEARCH FILTER
    if (this.searchTerm.trim()) {
      filtered = filtered.filter((product) =>
        product.name.toLowerCase().includes(this.searchTerm.toLowerCase()),
      );
    }

    return filtered;
  }

  get cartCount(): number {
    return this.cartService.getCount();
  }

  ngOnDestroy(): void {
    if (this.bannerInterval) {
      clearInterval(this.bannerInterval);
    }
  }
}
